/**
 * ============================================================================
 * webos_bridge.js — Host Adapter & Immediate-Mode Renderer for fe WebOS
 * ============================================================================
 */

class SExprBridge {
  constructor(ctx) {
    this.ctx = ctx;
  }

  encode(val) {
    if (val === null || val === undefined || val === false) return "nil";
    if (val === true) return "t";
    if (typeof val === "number") return String(val);
    if (typeof val === "string") {
      return `"${val.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/\t/g, "\\t")}"`;
    }
    if (Array.isArray(val)) {
      return "(" + val.map((x) => this.encode(x)).join(" ") + ")";
    }
    if (val && typeof val === "object" && val.type !== undefined) {
      return this.ctx.toString(val, true);
    }
    return `"${String(val)}"`;
  }
}

class SqliteSExprRepository {
  constructor(baseUrl = "") {
    this.baseUrl = baseUrl;
    this.cache = new Map();
  }

  syncRequest(method, url, bodyObj = null) {
    try {
      const xhr = new XMLHttpRequest();
      xhr.open(method, this.baseUrl + url, false);
      if (bodyObj !== null) {
        xhr.setRequestHeader("Content-Type", "application/json");
        xhr.send(JSON.stringify(bodyObj));
      } else {
        xhr.send(null);
      }
      if (xhr.status >= 200 && xhr.status < 300) {
        return JSON.parse(xhr.responseText);
      }
    } catch (_) {}
    return null;
  }

  listSExpr() {
    const res = this.syncRequest("GET", "/api/fs?format=json");
    if (res && res.ok && Array.isArray(res.nodes)) {
      this.cache.clear();
      return res.nodes.map((n) => {
        this.cache.set(n.path, n);
        return ["fs-node", ["path", n.path], ["kind", n.kind], ["content", n.sexpr_content], ["meta", n.sexpr_meta]];
      });
    }
    return Array.from(this.cache.values()).map((n) => [
      "fs-node",
      ["path", n.path],
      ["kind", n.kind],
      ["content", n.sexpr_content],
      ["meta", n.sexpr_meta],
    ]);
  }

  saveNode(path, kind, sexprContent) {
    const norm = path.startsWith("/") ? path : "/" + path;
    const res = this.syncRequest("POST", "/api/fs/save", {
      path: norm,
      kind: kind || "file",
      content: sexprContent,
      meta: "(sexpr sqlite3)",
    });
    if (res && res.ok && res.node) {
      this.cache.set(res.node.path, res.node);
      return ["fs-node", ["path", res.node.path], ["kind", res.node.kind], ["content", res.node.sexpr_content]];
    }
    const fallback = { path: norm, kind: kind || "file", sexpr_content: sexprContent };
    this.cache.set(norm, fallback);
    return ["fs-node", ["path", norm], ["kind", kind || "file"], ["content", sexprContent]];
  }

  loadNode(path) {
    const norm = path.startsWith("/") ? path : "/" + path;
    const res = this.syncRequest("GET", `/api/fs/node?path=${encodeURIComponent(norm)}`);
    if (res && res.ok && res.node) {
      this.cache.set(res.node.path, res.node);
      return ["fs-node", ["path", res.node.path], ["kind", res.node.kind], ["content", res.node.sexpr_content]];
    }
    const local = this.cache.get(norm);
    if (local) {
      return ["fs-node", ["path", local.path], ["kind", local.kind], ["content", local.sexpr_content]];
    }
    return null;
  }

  deleteNode(path) {
    const norm = path.startsWith("/") ? path : "/" + path;
    this.syncRequest("POST", "/api/fs/delete", { path: norm });
    this.cache.delete(norm);
    return true;
  }
}

class ImmediateGuiRenderer {
  constructor(ctx, repo) {
    this.ctx = ctx;
    this.repo = repo;
    this.lastTree = null;
  }

  _invokeAction(actionVal) {
    if (!actionVal) return;
    if (typeof actionVal === "function") {
      actionVal(this.ctx);
    } else if (actionVal && actionVal.type === FE_TYPE.SYMBOL) {
      const symName = this.ctx.toString(actionVal, false);
      this.ctx.evalString(`(${symName})`);
    } else if (typeof actionVal === "string") {
      this.ctx.evalString(`(${actionVal})`);
    }
  }

  _nth(lst, idx) {
    let cur = lst;
    let i = 0;
    while (!this.ctx.isNil(cur) && cur.type === FE_TYPE.PAIR) {
      if (i === idx) return this.ctx.car(cur);
      cur = this.ctx.cdr(cur);
      i++;
    }
    return this.ctx.nil;
  }

  _extractTreeParts(treeObj) {
    const rawWin = this._nth(treeObj, 1);
    const rawWidgets = this._nth(treeObj, 2);
    const win = this.ctx.toJS(rawWin);
    const widgets = [];
    let cur = rawWidgets;
    while (!this.ctx.isNil(cur) && cur.type === FE_TYPE.PAIR) {
      const item = this.ctx.car(cur);
      const jsItem = this.ctx.toJS(item);
      if (Array.isArray(jsItem) && jsItem[0] === "widget" && jsItem[1] === "icon-launcher") {
        jsItem[6] = this._nth(item, 6);
      }
      if (Array.isArray(jsItem) && jsItem[0] === "layout" && jsItem[1] === "desktop") {
        const rawIconsList = this._nth(item, 3);
        const iconsArr = [];
        let icCur = rawIconsList;
        while (!this.ctx.isNil(icCur) && icCur.type === FE_TYPE.PAIR) {
          const rawIc = this.ctx.car(icCur);
          const jsIc = this.ctx.toJS(rawIc);
          if (Array.isArray(jsIc)) {
            jsIc[6] = this._nth(rawIc, 6);
          }
          iconsArr.push(jsIc);
          icCur = this.ctx.cdr(icCur);
        }
        jsItem[3] = iconsArr;
      }
      widgets.push(jsItem);
      cur = this.ctx.cdr(cur);
    }
    return { win, widgets };
  }

  renderTree(treeObj) {
    document.documentElement.classList.add("dark");
    const { win, widgets } = this._extractTreeParts(treeObj);
    this.lastTree = { win, widgets };
    const mount = document.getElementById("webos-imgui-mount");
    if (!mount) return treeObj;

    mount.innerHTML = "";

    const desktopLayout = widgets.find((w) => Array.isArray(w) && w[0] === "layout" && w[1] === "desktop");
    if (desktopLayout) {
      const desktopEl = document.createElement("div");
      desktopEl.style.cssText = "height:100%;width:100%;background:#0d1117;color:#e6edf3;display:flex;flex-direction:column;justify-content:space-between;";

      const topBar = document.createElement("div");
      topBar.style.cssText = "background:#161b22;border-bottom:1px solid #30363d;padding:8px 14px;font-size:12px;display:flex;justify-content:space-between;align-items:center;";
      topBar.innerHTML = `<strong style="color:#58a6ff;">${this._esc(Array.isArray(win) ? win[1] : "fe WebOS Desktop")}</strong><span style="color:#8b949e;">DARK MODE · S-EXPR IMGUI</span>`;
      desktopEl.appendChild(topBar);

      const iconGrid = document.createElement("div");
      iconGrid.style.cssText = "flex:1;padding:24px;display:flex;flex-wrap:wrap;align-content:flex-start;gap:20px;";

      const icons = Array.isArray(desktopLayout[3]) ? desktopLayout[3] : [];
      for (const ic of icons) {
        if (Array.isArray(ic) && ic[0] === "widget" && ic[1] === "icon-launcher") {
          const svgMarkup = String(ic[3] ?? "");
          const title = String(ic[4] ?? "edit.fe");
          const onLaunch = ic[6];

          const btn = document.createElement("button");
          btn.id = String(ic[2] || "launch-edit-fe");
          btn.style.cssText = "width:104px;padding:14px 8px;background:#161b22;border:1px solid #30363d;border-radius:8px;color:#ffffff;display:flex;flex-direction:column;align-items:center;gap:8px;cursor:pointer;font-family:inherit;";
          btn.onmouseenter = () => { btn.style.borderColor = "#58a6ff"; btn.style.background = "#1f2630"; };
          btn.onmouseleave = () => { btn.style.borderColor = "#30363d"; btn.style.background = "#161b22"; };
          btn.onclick = () => this._invokeAction(onLaunch);

          const iconBox = document.createElement("div");
          iconBox.style.cssText = "width:48px;height:48px;border-radius:8px;background:#1f6feb;color:#ffffff;display:flex;align-items:center;justify-content:center;";
          iconBox.innerHTML = svgMarkup;

          const labelEl = document.createElement("span");
          labelEl.style.cssText = "font-size:12px;color:#e6edf3;word-break:break-all;";
          labelEl.textContent = title;

          btn.append(iconBox, labelEl);
          iconGrid.appendChild(btn);
        }
      }

      desktopEl.appendChild(iconGrid);
      mount.appendChild(desktopEl);
      return treeObj;
    }

    const shell = document.createElement("div");
    shell.style.cssText = "height:100%;width:100%;display:flex;flex-direction:column;background:#0d1117;color:#e6edf3;font-size:12px;";

    const titleBar = document.createElement("div");
    titleBar.style.cssText = "background:#161b22;border-bottom:1px solid #30363d;padding:8px 14px;display:flex;justify-content:space-between;align-items:center;";
    titleBar.innerHTML = `<strong style="color:#58a6ff;">${this._esc(Array.isArray(win) ? win[1] : "MS-DOS EDIT")}</strong><button id="webos-back-desktop" style="background:#21262d;color:#e6edf3;border:1px solid #30363d;border-radius:4px;padding:3px 8px;cursor:pointer;font-family:inherit;font-size:11px;">Desktop</button>`;
    shell.appendChild(titleBar);

    const body = document.createElement("div");
    body.style.cssText = "flex:1;display:flex;flex-direction:column;padding:10px;gap:8px;overflow:hidden;";

    const mainRow = document.createElement("div");
    mainRow.style.cssText = "flex:1;display:flex;gap:10px;overflow:hidden;";

    const sidebar = document.createElement("div");
    sidebar.style.cssText = "width:220px;background:#161b22;border:1px solid #30363d;border-radius:6px;padding:8px;display:flex;flex-direction:column;gap:6px;overflow-y:auto;";

    const editorCol = document.createElement("div");
    editorCol.style.cssText = "flex:1;background:#161b22;border:1px solid #30363d;border-radius:6px;padding:8px;display:flex;flex-direction:column;gap:8px;overflow:hidden;";

    let statusLeft = "Ready";
    let statusRight = "Line:1 Col:0";

    for (const w of widgets) {
      if (!Array.isArray(w)) continue;
      const kind = w[0];
      const wtype = w[1];

      if (kind === "widget" && wtype === "label") {
        const id = w[2];
        const text = String(w[3] ?? "");
        if (id === "dos-menubar") {
          const bar = document.createElement("div");
          bar.style.cssText = "background:#21262d;color:#e6edf3;border:1px solid #30363d;padding:5px 10px;border-radius:4px;font-weight:600;";
          bar.textContent = text;
          body.appendChild(bar);
        } else if (id === "dos-files-hdr") {
          const hdr = document.createElement("div");
          hdr.style.cssText = "font-size:11px;font-weight:700;color:#ffa657;border-bottom:1px solid #30363d;padding-bottom:4px;";
          hdr.textContent = text;
          sidebar.appendChild(hdr);
        } else {
          const lbl = document.createElement("div");
          lbl.style.cssText = "color:#58a6ff;font-weight:600;";
          lbl.textContent = text;
          editorCol.appendChild(lbl);
        }
      } else if (kind === "widget" && wtype === "list-box") {
        const items = Array.isArray(w[3]) ? w[3] : [];
        const onSelectSym = w[5];
        for (const item of items) {
          if (Array.isArray(item) && item[0] === "fs-node") {
            const pPair = item.find((x) => Array.isArray(x) && x[0] === "path");
            const kPair = item.find((x) => Array.isArray(x) && x[0] === "kind");
            const nodePath = pPair ? pPair[1] : "/";
            const nodeKind = kPair ? kPair[1] : "file";
            if (nodeKind === "file") {
              const btn = document.createElement("button");
              btn.style.cssText = "text-align:left;padding:5px 8px;border-radius:4px;background:transparent;border:none;color:#3fb950;cursor:pointer;font-family:inherit;font-size:12px;";
              btn.textContent = nodePath;
              btn.onclick = () => {
                if (onSelectSym) {
                  this.ctx.evalString(`(${onSelectSym} "${nodePath.replace(/"/g, '\\"')}") (edit/render)`);
                }
              };
              sidebar.appendChild(btn);
            }
          }
        }
      } else if (kind === "widget" && wtype === "button") {
        const label = String(w[3] ?? "Button");
        const actionFn = w[4];
        const btn = document.createElement("button");
        btn.style.cssText = "padding:6px 10px;border-radius:4px;background:#21262d;border:1px solid #30363d;color:#e6edf3;font-size:12px;text-align:left;cursor:pointer;font-family:inherit;";
        btn.textContent = label;
        btn.onclick = () => {
          this._invokeAction(actionFn);
          this.ctx.evalString("(edit/render)");
        };
        sidebar.appendChild(btn);
      } else if (kind === "widget" && wtype === "textarea") {
        const content = String(w[3] ?? "");
        const onChangeSym = w[7];
        const ta = document.createElement("textarea");
        ta.style.cssText = "flex:1;width:100%;background:#090d12;color:#79c0ff;padding:10px;border-radius:4px;border:1px solid #30363d;font-family:inherit;font-size:12px;line-height:1.5;resize:none;outline:none;box-sizing:border-box;";
        ta.value = content;
        ta.spellcheck = false;
        ta.oninput = () => {
          if (onChangeSym) {
            const escaped = ta.value
              .replace(/\\/g, "\\\\")
              .replace(/"/g, '\\"')
              .replace(/\n/g, "\\n");
            this.ctx.evalString(`(${onChangeSym} "${escaped}")`);
          }
        };
        editorCol.appendChild(ta);
      } else if (kind === "widget" && wtype === "status-bar") {
        statusLeft = String(w[3] ?? "");
        statusRight = String(w[4] ?? "");
      }
    }

    mainRow.append(sidebar, editorCol);
    body.appendChild(mainRow);

    const statusBar = document.createElement("div");
    statusBar.style.cssText = "background:#161b22;color:#8b949e;border:1px solid #30363d;padding:5px 10px;border-radius:4px;font-size:11px;display:flex;justify-content:space-between;";
    statusBar.innerHTML = `<span>${this._esc(statusLeft)}</span><span>${this._esc(statusRight)}</span>`;
    body.appendChild(statusBar);

    shell.appendChild(body);
    mount.appendChild(shell);

    const backBtn = document.getElementById("webos-back-desktop");
    if (backBtn) {
      backBtn.onclick = () => this.ctx.evalString("(webos/render-desktop)");
    }

    return treeObj;
  }

  _esc(s) {
    return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }
}

function registerWebOSHostBindings(ctx) {
  const bridge = new SExprBridge(ctx);
  const repo = new SqliteSExprRepository("");
  const renderer = new ImmediateGuiRenderer(ctx, repo);

  ctx.define("host/has-renderer", () => true);
  ctx.define("host/render-imgui", (c, tree) => renderer.renderTree(tree));
  ctx.define("host/has-fs-api", () => true);
  ctx.define("host/fs-list-sexpr", () => repo.listSExpr());
  ctx.define("host/fs-save", (c, path, kind, content) => repo.saveNode(path, kind, content));
  ctx.define("host/fs-load", (c, path) => repo.loadNode(path));
  ctx.define("host/fs-delete", (c, path) => repo.deleteNode(path));
  ctx.define("host/now-iso", () => new Date().toISOString());

  ctx.define("host/eval-fe-safe", (c, code) => {
    try {
      return c.evalString(String(code));
    } catch (err) {
      return ["error", String(err.message || err)];
    }
  });

  ctx.define("sexpr/encode", (c, val) => bridge.encode(val));
  ctx.define("read-sexpr", (c, src) => {
    const stream = new StringStream(String(src));
    return c.read(stream);
  });
  ctx.define("type", (c, obj) => FE_TYPENAMES[c.type(obj)] || "unknown");
  ctx.define("str/concat", (c, ...parts) => parts.map((p) => (p === null || p === undefined ? "" : String(p))).join(""));
  ctx.define("str/slice", (c, s, start, end) => String(s).slice(start, end));
  ctx.define("apply", (c, fnObj, argsList) => {
    const arr = c.toArray(argsList);
    const feArgs = arr.map((x) => c.fromJS(x));
    const callForm = c.list([fnObj, ...feArgs]);
    return c.eval(callForm);
  });

  ctx.define("ui/dict-get", (c, alist, key, fallback) => {
    const targetKey = String(key);
    let cur = alist;
    while (!c.isNil(cur)) {
      const entry = c.car(cur);
      if (entry && entry.type === FE_TYPE.PAIR && !c.isNil(entry.car) && !c.isNil(entry.cdr)) {
        const k = entry.car.type === FE_TYPE.SYMBOL ? entry.car.cdr.car.cdr : c.toJS(entry.car);
        if (String(k) === targetKey) {
          return entry.cdr.type === FE_TYPE.PAIR ? c.car(entry.cdr) : entry.cdr;
        }
      }
      cur = c.cdr(cur);
    }
    return fallback !== undefined ? c.fromJS(fallback) : c.nil;
  });

  ctx.define("ui/dict-set", (c, alist, key, val) => {
    const targetKey = String(key);
    const feVal = c.fromJS(val);
    const newEntry = c.list([c.symbol(targetKey), feVal]);
    const items = [];
    let replaced = false;
    let cur = alist;
    while (!c.isNil(cur)) {
      const entry = c.car(cur);
      if (entry && entry.type === FE_TYPE.PAIR && !c.isNil(entry.car)) {
        const k = entry.car.type === FE_TYPE.SYMBOL ? entry.car.cdr.car.cdr : c.toJS(entry.car);
        if (String(k) === targetKey) {
          items.push(newEntry);
          replaced = true;
        } else {
          items.push(entry);
        }
      } else {
        items.push(entry);
      }
      cur = c.cdr(cur);
    }
    if (!replaced) {
      items.push(newEntry);
    }
    return c.list(items);
  });

  ctx.define("ui/append", (c, lst, item) => {
    const arr = c.isNil(lst) ? [] : (() => {
      const out = [];
      let cur = lst;
      while (!c.isNil(cur)) {
        out.push(c.car(cur));
        cur = c.cdr(cur);
      }
      return out;
    })();
    arr.push(c.fromJS(item));
    return c.list(arr);
  });
}




const EMBEDDED_FE_MODULES = [
  { name: "/fe_src/imgui.fe", b64: "KD0gaW1ndWktc3RhdGUgKGxpc3QgJ2ltZ3VpLWN0eAogIChsaXN0ICdob3QgbmlsKQogIChsaXN0ICdhY3RpdmUgbmlsKQogIChsaXN0ICdmb2N1cyBuaWwpCiAgKGxpc3QgJ3dpZGdldHMgbmlsKQogIChsaXN0ICdkYXJrLW1vZGUgJ3QpCiAgKGxpc3QgJ3RoZW1lIChsaXN0ICd0aGVtZQogICAgKGxpc3QgJ21vZGUgJ2RhcmspCiAgICAobGlzdCAnYmcgIiMwZDExMTciKQogICAgKGxpc3QgJ3BhbmVsICIjMTYxYjIyIikKICAgIChsaXN0ICdhY2NlbnQgIiM1OGE2ZmYiKQogICAgKGxpc3QgJ3RleHQgIiNlNmVkZjMiKQogICAgKGxpc3QgJ2JvcmRlciAiIzMwMzYzZCIpKSkpKQoKKD0gaW1ndWkvYmVnaW4tZnJhbWUgKGZuICh0aXRsZSB3IGgpCiAgKGRvCiAgICAoPSBpbWd1aS1zdGF0ZQogICAgICAobGlzdCAnaW1ndWktY3R4CiAgICAgICAgKGxpc3QgJ2hvdCBuaWwpCiAgICAgICAgKGxpc3QgJ2FjdGl2ZSAodWkvZGljdC1nZXQgaW1ndWktc3RhdGUgJ2FjdGl2ZSBuaWwpKQogICAgICAgIChsaXN0ICdmb2N1cyAodWkvZGljdC1nZXQgaW1ndWktc3RhdGUgJ2ZvY3VzIG5pbCkpCiAgICAgICAgKGxpc3QgJ3dpZGdldHMgbmlsKQogICAgICAgIChsaXN0ICdkYXJrLW1vZGUgJ3QpCiAgICAgICAgKGxpc3QgJ3RoZW1lICh1aS9kaWN0LWdldCBpbWd1aS1zdGF0ZSAndGhlbWUgbmlsKSkKICAgICAgICAobGlzdCAnd2luZG93IChsaXN0ICd3aW5kb3cgdGl0bGUgdyBoKSkpKQogICAgKGxpc3QgJ2ZyYW1lLWJlZ2luIHRpdGxlIHcgaCkpKSkKCig9IGltZ3VpL3NldC1ob3QgKGZuIChpZCkKICAoZG8KICAgIChsZXQgc3QgaW1ndWktc3RhdGUpCiAgICAobGV0IGN1ci1hY3RpdmUgKHVpL2RpY3QtZ2V0IHN0ICdhY3RpdmUgbmlsKSkKICAgIChpZiAobm90IGN1ci1hY3RpdmUpCiAgICAgICAgKD0gaW1ndWktc3RhdGUgKHVpL2RpY3Qtc2V0IHN0ICdob3QgaWQpKSkKICAgIGlkKSkpCgooPSBpbWd1aS9lbWl0IChmbiAobm9kZSkKICAoZG8KICAgIChsZXQgc3QgaW1ndWktc3RhdGUpCiAgICAobGV0IHdzICh1aS9kaWN0LWdldCBzdCAnd2lkZ2V0cyBuaWwpKQogICAgKD0gaW1ndWktc3RhdGUgKHVpL2RpY3Qtc2V0IHN0ICd3aWRnZXRzICh1aS9hcHBlbmQgd3Mgbm9kZSkpKQogICAgbm9kZSkpKQoKKD0gaW1ndWkvbGFiZWwgKGZuIChpZCB0ZXh0KQogIChpbWd1aS9lbWl0IChsaXN0ICd3aWRnZXQgJ2xhYmVsIGlkIHRleHQpKSkpCgooPSBpbWd1aS9idXR0b24gKGZuIChpZCBsYWJlbCBvbi1jbGljaykKICAoZG8KICAgIChpbWd1aS9zZXQtaG90IGlkKQogICAgKGltZ3VpL2VtaXQgKGxpc3QgJ3dpZGdldCAnYnV0dG9uIGlkIGxhYmVsIG9uLWNsaWNrKSkpKSkKCig9IGltZ3VpL2ljb24tbGF1bmNoZXIgKGZuIChpZCBzdmctbWFya3VwIHRpdGxlIG9uLWxhdW5jaCkKICAoZG8KICAgIChpbWd1aS9zZXQtaG90IGlkKQogICAgKGxldCBpcy1ob3QgKGlzICh1aS9kaWN0LWdldCBpbWd1aS1zdGF0ZSAnaG90IG5pbCkgaWQpKQogICAgKGltZ3VpL2VtaXQgKGxpc3QgJ3dpZGdldCAnaWNvbi1sYXVuY2hlciBpZCBzdmctbWFya3VwIHRpdGxlIChsaXN0ICdob3QgaXMtaG90KSBvbi1sYXVuY2gpKSkpKQoKKD0gaW1ndWkvZGVza3RvcCAoZm4gKGlkIGljb25zKQogIChpbWd1aS9lbWl0IChsaXN0ICdsYXlvdXQgJ2Rlc2t0b3AgaWQgaWNvbnMpKSkpCgooPSBpbWd1aS90ZXh0YXJlYSAoZm4gKGlkIGNvbnRlbnQgY3Vyc29yLWxpbmUgY3Vyc29yLWNvbCBvbi1jaGFuZ2UpCiAgKGRvCiAgICAoaW1ndWkvc2V0LWhvdCBpZCkKICAgIChpbWd1aS9lbWl0IChsaXN0ICd3aWRnZXQgJ3RleHRhcmVhIGlkIGNvbnRlbnQgY3Vyc29yLWxpbmUgY3Vyc29yLWNvbCBvbi1jaGFuZ2UpKSkpKQoKKD0gaW1ndWkvbGlzdC1ib3ggKGZuIChpZCBpdGVtcyBzZWxlY3RlZC1pZHggb24tc2VsZWN0KQogIChkbwogICAgKGltZ3VpL3NldC1ob3QgaWQpCiAgICAoaW1ndWkvZW1pdCAobGlzdCAnd2lkZ2V0ICdsaXN0LWJveCBpZCBpdGVtcyBzZWxlY3RlZC1pZHggb24tc2VsZWN0KSkpKSkKCig9IGltZ3VpL2hzcGxpdCAoZm4gKGlkIHJhdGlvIGxlZnQtbm9kZSByaWdodC1ub2RlKQogIChpbWd1aS9lbWl0IChsaXN0ICdsYXlvdXQgJ2hzcGxpdCBpZCByYXRpbyBsZWZ0LW5vZGUgcmlnaHQtbm9kZSkpKSkKCig9IGltZ3VpL3ZzdGFjayAoZm4gKGlkIGNoaWxkcmVuKQogIChpbWd1aS9lbWl0IChsaXN0ICdsYXlvdXQgJ3ZzdGFjayBpZCBjaGlsZHJlbikpKSkKCig9IGltZ3VpL3N0YXR1cy1iYXIgKGZuIChpZCBsZWZ0LXRleHQgcmlnaHQtdGV4dCkKICAoaW1ndWkvZW1pdCAobGlzdCAnd2lkZ2V0ICdzdGF0dXMtYmFyIGlkIGxlZnQtdGV4dCByaWdodC10ZXh0KSkpKQoKKD0gaW1ndWkvZW5kLWZyYW1lIChmbiAoKQogIChkbwogICAgKGxldCBzdCBpbWd1aS1zdGF0ZSkKICAgIChsZXQgd2luICh1aS9kaWN0LWdldCBzdCAnd2luZG93IChsaXN0ICd3aW5kb3cgImZlIFdlYk9TIiAxMDI0IDY0MCkpKQogICAgKGxldCB3cyAodWkvZGljdC1nZXQgc3QgJ3dpZGdldHMgbmlsKSkKICAgIChsZXQgdHJlZSAobGlzdCAndWktdHJlZSB3aW4gd3MgKGxpc3QgJ2RhcmstbW9kZSAndCkpKQogICAgKGlmIChob3N0L2hhcy1yZW5kZXJlcikKICAgICAgICAoaG9zdC9yZW5kZXItaW1ndWkgdHJlZSkpCiAgICB0cmVlKSkpCg==" },
  { name: "/fe_src/fs.fe", b64: "KD0gZnMvLWNhY2hlIG5pbCkKCig9IGZzL25vcm1hbGl6ZS1wYXRoIChmbiAocCkKICAoaWYgKG9yIChub3QgcCkgKGlzIHAgIiIpIChpcyBwICIvIikpCiAgICAgICIvIgogICAgICAoaWYgKGlzIChzdHIvc2xpY2UgcCAwIDEpICIvIikKICAgICAgICAgIHAKICAgICAgICAgIChzdHIvY29uY2F0ICIvIiBwKSkpKSkKCig9IGZzL21ha2Utbm9kZSAoZm4gKHBhdGgga2luZCBjb250ZW50IG1ldGEpCiAgKGxpc3QgJ2ZzLW5vZGUKICAgIChsaXN0ICdwYXRoIChmcy9ub3JtYWxpemUtcGF0aCBwYXRoKSkKICAgIChsaXN0ICdraW5kIGtpbmQpCiAgICAobGlzdCAnY29udGVudCBjb250ZW50KQogICAgKGxpc3QgJ21ldGEgbWV0YSkpKSkKCig9IGZzL25vZGUtcGF0aCAoZm4gKG4pICh1aS9kaWN0LWdldCBuICdwYXRoICIvIikpKQooPSBmcy9ub2RlLWtpbmQgKGZuIChuKSAodWkvZGljdC1nZXQgbiAna2luZCAnZmlsZSkpKQooPSBmcy9ub2RlLWNvbnRlbnQgKGZuIChuKSAodWkvZGljdC1nZXQgbiAnY29udGVudCBuaWwpKSkKCig9IGZzL2Jvb3QgKGZuICgpCiAgKGRvCiAgICAobGV0IHJvb3QgKGZzL21ha2Utbm9kZSAiLyIgJ2RpciAnKCkgKGxpc3QgJ2Zvcm1hdCAnc2V4cHIpKSkKICAgICg9IGZzLy1jYWNoZSAobGlzdCByb290KSkKICAgIChpZiAoaG9zdC9oYXMtZnMtYXBpKQogICAgICAgIChkbwogICAgICAgICAgKGxldCByZW1vdGUgKGhvc3QvZnMtbGlzdC1zZXhwcikpCiAgICAgICAgICAoaWYgcmVtb3RlCiAgICAgICAgICAgICAgKD0gZnMvLWNhY2hlIHJlbW90ZSkpKSkKICAgIGZzLy1jYWNoZSkpKQoKKD0gZnMvd3JpdGUtZmlsZSAoZm4gKHBhdGggc2V4cHItY29udGVudCkKICAoZG8KICAgIChsZXQgbm9ybSAoZnMvbm9ybWFsaXplLXBhdGggcGF0aCkpCiAgICAobGV0IHNlcmlhbGl6ZWQKICAgICAgKGlmIChpcyAodHlwZSBzZXhwci1jb250ZW50KSAnc3RyaW5nKQogICAgICAgICAgc2V4cHItY29udGVudAogICAgICAgICAgKHNleHByL2VuY29kZSBzZXhwci1jb250ZW50KSkpCiAgICAobGV0IG5vZGUgKGZzL21ha2Utbm9kZSBub3JtICdmaWxlIHNlcmlhbGl6ZWQgKGxpc3QgJ2Zvcm1hdCAnc2V4cHIpKSkKICAgICg9IGZzLy1jYWNoZSAoZnMvLXVwc2VydC1jYWNoZSBub2RlKSkKICAgIChpZiAoaG9zdC9oYXMtZnMtYXBpKQogICAgICAgIChob3N0L2ZzLXNhdmUgbm9ybSAnZmlsZSBzZXJpYWxpemVkKSkKICAgIG5vZGUpKSkKCig9IGZzL3JlYWQtZmlsZSAoZm4gKHBhdGgpCiAgKGRvCiAgICAobGV0IG5vcm0gKGZzL25vcm1hbGl6ZS1wYXRoIHBhdGgpKQogICAgKGxldCBjYWNoZWQgKGZzLy1maW5kLWNhY2hlIG5vcm0pKQogICAgKGlmIGNhY2hlZAogICAgICAgIChmcy9ub2RlLWNvbnRlbnQgY2FjaGVkKQogICAgICAgIChpZiAoaG9zdC9oYXMtZnMtYXBpKQogICAgICAgICAgICAoZG8KICAgICAgICAgICAgICAobGV0IGxvYWRlZCAoaG9zdC9mcy1sb2FkIG5vcm0pKQogICAgICAgICAgICAgIChpZiBsb2FkZWQKICAgICAgICAgICAgICAgICAgKGRvCiAgICAgICAgICAgICAgICAgICAgKD0gZnMvLWNhY2hlIChmcy8tdXBzZXJ0LWNhY2hlIGxvYWRlZCkpCiAgICAgICAgICAgICAgICAgICAgKGZzL25vZGUtY29udGVudCBsb2FkZWQpKQogICAgICAgICAgICAgICAgICBuaWwpKQogICAgICAgICAgICBuaWwpKSkpKQoKKD0gZnMvbGlzdC1lbnRyaWVzIChmbiAoKQogIChkbwogICAgKGlmIChob3N0L2hhcy1mcy1hcGkpCiAgICAgICAgKGRvCiAgICAgICAgICAobGV0IHN5bmNlZCAoaG9zdC9mcy1saXN0LXNleHByKSkKICAgICAgICAgIChpZiBzeW5jZWQKICAgICAgICAgICAgICAoPSBmcy8tY2FjaGUgc3luY2VkKSkpKQogICAgZnMvLWNhY2hlKSkpCgooPSBmcy8tdXBzZXJ0LWNhY2hlIChmbiAobmV3LW5vZGUpCiAgKGRvCiAgICAobGV0IHRhcmdldC1wYXRoIChmcy9ub2RlLXBhdGggbmV3LW5vZGUpKQogICAgKGxldCBvdXQgbmlsKQogICAgKGxldCBmb3VuZCBuaWwpCiAgICAobGV0IGN1ciBmcy8tY2FjaGUpCiAgICAod2hpbGUgY3VyCiAgICAgIChkbwogICAgICAgIChsZXQgaXRlbSAoY2FyIGN1cikpCiAgICAgICAgKGlmIChpcyAoZnMvbm9kZS1wYXRoIGl0ZW0pIHRhcmdldC1wYXRoKQogICAgICAgICAgICAoZG8KICAgICAgICAgICAgICAoPSBvdXQgKHVpL2FwcGVuZCBvdXQgbmV3LW5vZGUpKQogICAgICAgICAgICAgICg9IGZvdW5kICd0KSkKICAgICAgICAgICAgKD0gb3V0ICh1aS9hcHBlbmQgb3V0IGl0ZW0pKSkKICAgICAgICAoPSBjdXIgKGNkciBjdXIpKSkpCiAgICAoaWYgKG5vdCBmb3VuZCkKICAgICAgICAoPSBvdXQgKHVpL2FwcGVuZCBvdXQgbmV3LW5vZGUpKSkKICAgIG91dCkpKQoKKD0gZnMvLWZpbmQtY2FjaGUgKGZuICh0YXJnZXQtcGF0aCkKICAoZG8KICAgIChsZXQgY3VyIGZzLy1jYWNoZSkKICAgIChsZXQgcmVzdWx0IG5pbCkKICAgICh3aGlsZSAoYW5kIGN1ciAobm90IHJlc3VsdCkpCiAgICAgIChkbwogICAgICAgIChsZXQgaXRlbSAoY2FyIGN1cikpCiAgICAgICAgKGlmIChpcyAoZnMvbm9kZS1wYXRoIGl0ZW0pIHRhcmdldC1wYXRoKQogICAgICAgICAgICAoPSByZXN1bHQgaXRlbSkpCiAgICAgICAgKD0gY3VyIChjZHIgY3VyKSkpKQogICAgcmVzdWx0KSkpCg==" },
  { name: "/fe_src/edit.fe", b64: "KD0gZWRpdC1tb2RlbCAobGlzdCAnZWRpdC1tb2RlbAogIChsaXN0ICdwYXRoICIvaGVsbG8uZmUiKQogIChsaXN0ICdidWZmZXIgIihwcmludCBcIkhlbGxvIGZyb20gRE9TIEVESVQuQ09NIG9uIFdlYk9TIVwiKSIpCiAgKGxpc3QgJ2RpcnR5IG5pbCkKICAobGlzdCAnY3Vyc29yLWxpbmUgMSkKICAobGlzdCAnY3Vyc29yLWNvbCAwKQogIChsaXN0ICdzdGF0dXMgIkYyOlNhdmUgIEY1OlJ1biAgRjQ6TmV3IikpKQoKKD0gZWRpdC9nZXQgKGZuIChrZXkgZGVmYXVsdC12YWwpCiAgKHVpL2RpY3QtZ2V0IGVkaXQtbW9kZWwga2V5IGRlZmF1bHQtdmFsKSkpCgooPSBlZGl0L3NldCAoZm4gKGtleSB2YWwpCiAgKGRvCiAgICAoPSBlZGl0LW1vZGVsICh1aS9kaWN0LXNldCBlZGl0LW1vZGVsIGtleSB2YWwpKQogICAgZWRpdC1tb2RlbCkpKQoKKD0gZWRpdC9jbWQtbmV3IChmbiAobmV3LXBhdGgpCiAgKGRvCiAgICAobGV0IHRhcmdldCAoaWYgKGFuZCBuZXctcGF0aCAobm90IChpcyBuZXctcGF0aCAiIikpKSBuZXctcGF0aCAiL3VudGl0bGVkLmZlIikpCiAgICAoZWRpdC9zZXQgJ3BhdGggKGZzL25vcm1hbGl6ZS1wYXRoIHRhcmdldCkpCiAgICAoZWRpdC9zZXQgJ2J1ZmZlciAiKCkiKQogICAgKGVkaXQvc2V0ICdkaXJ0eSBuaWwpCiAgICAoZWRpdC9zZXQgJ3N0YXR1cyAoc3RyL2NvbmNhdCAiTmV3IGJ1ZmZlcjogIiAoZnMvbm9ybWFsaXplLXBhdGggdGFyZ2V0KSkpKSkpCgooPSBlZGl0L2NtZC1vcGVuIChmbiAodGFyZ2V0LXBhdGgpCiAgKGRvCiAgICAobGV0IG5vcm0gKGZzL25vcm1hbGl6ZS1wYXRoIHRhcmdldC1wYXRoKSkKICAgIChsZXQgY29udGVudCAoZnMvcmVhZC1maWxlIG5vcm0pKQogICAgKGlmIGNvbnRlbnQKICAgICAgICAoZG8KICAgICAgICAgIChlZGl0L3NldCAncGF0aCBub3JtKQogICAgICAgICAgKGVkaXQvc2V0ICdidWZmZXIgY29udGVudCkKICAgICAgICAgIChlZGl0L3NldCAnZGlydHkgbmlsKQogICAgICAgICAgKGVkaXQvc2V0ICdzdGF0dXMgKHN0ci9jb25jYXQgIk9wZW5lZDogIiBub3JtKSkpCiAgICAgICAgKGVkaXQvc2V0ICdzdGF0dXMgKHN0ci9jb25jYXQgIk5vdCBmb3VuZDogIiBub3JtKSkpKSkpCgooPSBlZGl0L2NtZC1zYXZlIChmbiAoKQogIChkbwogICAgKGxldCBwIChlZGl0L2dldCAncGF0aCAiL3VudGl0bGVkLmZlIikpCiAgICAobGV0IGJ1ZiAoZWRpdC9nZXQgJ2J1ZmZlciAiIikpCiAgICAoZnMvd3JpdGUtZmlsZSBwIGJ1ZikKICAgIChlZGl0L3NldCAnZGlydHkgbmlsKQogICAgKGVkaXQvc2V0ICdzdGF0dXMgKHN0ci9jb25jYXQgIlNhdmVkIFsiIHAgIl0gdG8gU1FMaXRlIFMtRXhwciBzdG9yZSIpKSkpKQoKKD0gZWRpdC9jbWQtcnVuIChmbiAoKQogIChkbwogICAgKGxldCBidWYgKGVkaXQvZ2V0ICdidWZmZXIgIiIpKQogICAgKGxldCByZXMgKGhvc3QvZXZhbC1mZS1zYWZlIGJ1ZikpCiAgICAoZWRpdC9zZXQgJ3N0YXR1cyAoc3RyL2NvbmNhdCAiUlVOID0+ICIgKHNleHByL2VuY29kZSByZXMpKSkKICAgIHJlcykpKQoKKD0gZWRpdC9jbWQtc2V0LWJ1ZmZlciAoZm4gKG5ldy1idWYpCiAgKGRvCiAgICAoZWRpdC9zZXQgJ2J1ZmZlciBuZXctYnVmKQogICAgKGVkaXQvc2V0ICdkaXJ0eSAndCkKICAgIChlZGl0L3NldCAnc3RhdHVzICJNb2RpZmllZCAoKikiKSkpKQoKKD0gZWRpdC9yZW5kZXIgKGZuICgpCiAgKGRvCiAgICAoaW1ndWkvYmVnaW4tZnJhbWUgIk1TLURPUyBFRElUIC0gV2ViT1MgUy1FeHByIEVkaXRvciIgMTAyNCA2NDApCiAgICAobGV0IHBhdGggKGVkaXQvZ2V0ICdwYXRoICIvdW50aXRsZWQuZmUiKSkKICAgIChsZXQgZGlydHkgKGVkaXQvZ2V0ICdkaXJ0eSBuaWwpKQogICAgKGxldCBidWYgKGVkaXQvZ2V0ICdidWZmZXIgIiIpKQogICAgKGxldCBjbGluZSAoZWRpdC9nZXQgJ2N1cnNvci1saW5lIDEpKQogICAgKGxldCBjY29sIChlZGl0L2dldCAnY3Vyc29yLWNvbCAwKSkKICAgIChsZXQgc3RhdHVzIChlZGl0L2dldCAnc3RhdHVzICIiKSkKICAgIChsZXQgZmlsZXMgKGZzL2xpc3QtZW50cmllcykpCiAgICAobGV0IGhlYWRlci1sYWJlbAogICAgICAoc3RyL2NvbmNhdCAoaWYgZGlydHkgIiogIiAiICAiKSBwYXRoICIgIHwgIEZpbGUgIEVkaXQgIFNlYXJjaCAgUnVuICBPcHRpb25zIikpCiAgICAobGV0IHRvcC1iYXIgKGltZ3VpL2xhYmVsICJkb3MtbWVudWJhciIgaGVhZGVyLWxhYmVsKSkKICAgIChsZXQgc2lkZWJhcgogICAgICAoaW1ndWkvdnN0YWNrICJkb3Mtc2lkZWJhciIKICAgICAgICAobGlzdAogICAgICAgICAgKGltZ3VpL2xhYmVsICJkb3MtZmlsZXMtaGRyIiAiUy1FWFBSIEZJTEVTIChTUUxpdGUpIikKICAgICAgICAgIChpbWd1aS9saXN0LWJveCAiZG9zLWZpbGUtbGlzdCIgZmlsZXMgMCAnZWRpdC9jbWQtb3BlbikKICAgICAgICAgIChpbWd1aS9idXR0b24gImRvcy1idG4tbmV3IiAiW0Y0XSBOZXciIChmbiAoKSAoZWRpdC9jbWQtbmV3ICIvbmV3LmZlIikpKQogICAgICAgICAgKGltZ3VpL2J1dHRvbiAiZG9zLWJ0bi1zYXZlIiAiW0YyXSBTYXZlIiBlZGl0L2NtZC1zYXZlKQogICAgICAgICAgKGltZ3VpL2J1dHRvbiAiZG9zLWJ0bi1ydW4iICJbRjVdIFJ1biIgZWRpdC9jbWQtcnVuKSkpKQogICAgKGxldCBlZGl0b3ItcGFuZQogICAgICAoaW1ndWkvdnN0YWNrICJkb3MtZWRpdG9yLWNvbCIKICAgICAgICAobGlzdAogICAgICAgICAgKGltZ3VpL2xhYmVsICJkb3MtZmlsZS1wYXRoIiAoc3RyL2NvbmNhdCAiRWRpdGluZzogIiBwYXRoKSkKICAgICAgICAgIChpbWd1aS90ZXh0YXJlYSAiZG9zLWNvZGUtYXJlYSIgYnVmIGNsaW5lIGNjb2wgJ2VkaXQvY21kLXNldC1idWZmZXIpKSkpCiAgICAobGV0IG1haW4tc3BsaXQgKGltZ3VpL2hzcGxpdCAiZG9zLW1haW4tc3BsaXQiIDAuMjYgc2lkZWJhciBlZGl0b3ItcGFuZSkpCiAgICAobGV0IGJvdHRvbS1iYXIgKGltZ3VpL3N0YXR1cy1iYXIgImRvcy1zdGF0dXNiYXIiIHN0YXR1cyAoc3RyL2NvbmNhdCAiTGluZToiIGNsaW5lICIgQ29sOiIgY2NvbCkpKQogICAgKGltZ3VpL3ZzdGFjayAiZG9zLXJvb3QiIChsaXN0IHRvcC1iYXIgbWFpbi1zcGxpdCBib3R0b20tYmFyKSkKICAgIChpbWd1aS9lbmQtZnJhbWUpKSkpCg==" },
  { name: "/fe_src/webos.fe", b64: "KD0gd2Vib3Mtc3RhdGUgKGxpc3QgJ3dlYm9zLXN0YXRlCiAgKGxpc3QgJ3J1bm5pbmctYXBwICdkZXNrdG9wKSkpCgooPSB3ZWJvcy9sYXVuY2gtZWRpdCAoZm4gKCkKICAoZG8KICAgICg9IHdlYm9zLXN0YXRlICh1aS9kaWN0LXNldCB3ZWJvcy1zdGF0ZSAncnVubmluZy1hcHAgJ2VkaXQpKQogICAgKGVkaXQvY21kLW9wZW4gIi9oZWxsby5mZSIpCiAgICAoZWRpdC9yZW5kZXIpKSkpCgooPSB3ZWJvcy9yZW5kZXItZGVza3RvcCAoZm4gKCkKICAoZG8KICAgIChpbWd1aS9iZWdpbi1mcmFtZSAiZmUgV2ViT1MgRGVza3RvcCIgMTAyNCA2NDApCiAgICAobGV0IGVkaXQtc3ZnICI8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgd2lkdGg9XCIyOFwiIGhlaWdodD1cIjI4XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiBzdHJva2Utd2lkdGg9XCIyXCIgc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZS1saW5lam9pbj1cInJvdW5kXCI+PHBhdGggZD1cIk0xMiAyMGg5XCIvPjxwYXRoIGQ9XCJNMTYuNSAzLjVhMi4xMiAyLjEyIDAgMCAxIDMgM0w3IDE5bC00IDEgMS00WlwiLz48L3N2Zz4iKQogICAgKGxldCBlZGl0LWljb24gKGltZ3VpL2ljb24tbGF1bmNoZXIgImxhdW5jaC1lZGl0LWZlIiBlZGl0LXN2ZyAiZWRpdC5mZSIgJ3dlYm9zL2xhdW5jaC1lZGl0KSkKICAgIChpbWd1aS9kZXNrdG9wICJ3ZWJvcy1kZXNrdG9wIiAobGlzdCBlZGl0LWljb24pKQogICAgKGltZ3VpL2VuZC1mcmFtZSkpKSkKCig9IHdlYm9zL2Jvb3QgKGZuICgpCiAgKGRvCiAgICAoZnMvYm9vdCkKICAgIChpZiAobm90IChmcy9yZWFkLWZpbGUgIi9oZWxsby5mZSIpKQogICAgICAgIChmcy93cml0ZS1maWxlICIvaGVsbG8uZmUiCiAgICAgICAgICAiKGRvXG4gIChwcmludCBcIldlbGNvbWUgdG8gZmUgV2ViT1MhXCIpXG4gIChsaXN0ICdvcyAnZmUtbGlzcCAnc3RvcmFnZSAnc3FsaXRlLXNleHByKSkiKSkKICAgICh3ZWJvcy9yZW5kZXItZGVza3RvcCkpKSkK" }
];

function _decodeUtf8Base64(b64) {
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) {
    bytes[i] = bin.charCodeAt(i);
  }
  return new TextDecoder("utf-8").decode(bytes);
}

function bootWebOS() {
  document.documentElement.classList.add("dark");
  const ctx = new FeContext({ onPrint: (t) => console.log("[fe]", t) });
  window.fe = ctx;
  registerWebOSHostBindings(ctx);

  for (const mod of EMBEDDED_FE_MODULES) {
    try {
      const code = _decodeUtf8Base64(mod.b64);
      ctx.evalString(code);
    } catch (err) {
      console.error("[fe] Failed evaluating", mod.name, err);
      return;
    }
  }
  try {
    ctx.evalString("(webos/boot)");
  } catch (err) {
    console.error("[fe] Failed in (webos/boot)", err);
  }

  window.addEventListener("keydown", (e) => {
    if (e.key === "F2") {
      e.preventDefault();
      ctx.evalString("(edit/cmd-save) (edit/render)");
    } else if (e.key === "F5") {
      e.preventDefault();
      ctx.evalString("(edit/cmd-run) (edit/render)");
    } else if (e.key === "F4") {
      e.preventDefault();
      ctx.evalString('(edit/cmd-new "/new.fe") (edit/render)');
    }
  });
}

window.addEventListener("DOMContentLoaded", bootWebOS);
